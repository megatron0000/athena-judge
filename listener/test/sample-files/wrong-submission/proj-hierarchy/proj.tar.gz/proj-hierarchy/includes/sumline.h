#include <iostream>

int sumline(std::string line);